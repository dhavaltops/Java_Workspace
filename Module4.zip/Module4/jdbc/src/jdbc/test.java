package jdbc;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSet;

public class test implements ActionListener
{
	JFrame frame;
	JButton insertbtn,viewbtn,updatebtn,deletebtn;
	
	public test() 
	{
		frame=new JFrame();
		
		insertbtn=new JButton("INSERT");
		viewbtn=new JButton("VIEW");
		updatebtn=new JButton("UPDATE");
		deletebtn=new JButton("DELETE");
		
		
		insertbtn.addActionListener(this);
		viewbtn.addActionListener(this);
		
		
		frame.add(insertbtn);
		frame.add(viewbtn);
		frame.add(updatebtn);
		frame.add(deletebtn);
		frame.setSize(500,500);
		frame.setLayout(new FlowLayout());
		frame.setVisible(true);
	}
	
	public static void main(String[] args) 
	{
		
		new test();
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Alloperations a =new Alloperations();
		// TODO Auto-generated method stub
		if(e.getSource()==insertbtn)
		{
			a.insertdata();
		}
		if(e.getSource ()== viewbtn)
		{
			a.viewdata();
		}
	}
}

class Alloperations

{
	private static final DriverManager DriveManager = null;
	JFrame insertframe,updateframe,deleteframe;
	JButton insert,view,update,delete;
	JTextField name,surname;
	
	public void insertdata()
	
	{
		insertframe =new JFrame();
		
			
		name =new JTextField(20);
		surname=new JTextField(20);
		insert=new JButton("INSERT DATA");
		
		insert.addActionListener(new ActionListener() {
			
			private Throwable e;
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				//installation steps
				
				String host="jdbc:mysql://localhost:3306/";
				String db="first";  								// table name (first)
				String url=host+db;
				
				
				try 
				{
					
					//installation done
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection(url,"root","");
					
					String name1=name.getText().toString();
					String surname1=surname.getText().toString();
					
					
					//query execute
					String sql="insert into first values(null,'"+name1+"','"+surname1+"')";   //database name (first)
					
					
					Statement stmt=con.createStatement();
					
					int data=stmt.executeUpdate(sql);
					
					if(data>0)
					{
						System.out.println("Inserted");
						insertframe.setVisible(false);
					}
					else
					{
						System.out.println("Error");
					}	
				}
				catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
		});
		insertframe.add(name);
		insertframe.add(surname);
		insertframe.add(insert);
		insertframe.setSize(500, 500);
		insertframe.setLayout(new FlowLayout());
		insertframe.setVisible(true);
	}	
public void viewdata()
{
	String host="jdbc:mysql://localhost:3306/";
	String db="first";  								// table name (first)
	String url=host+db;
	
	try
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriveManager.getConnection(url,"root","");
		
		String sql = "select * from first";
		
		Statement stmt = con.createStatement();
		ResultSet set = (ResultSet) stmt.executeQuery(sql);
		
		while(set.next())
		{
			int id1= set.getInt(1);
			String name1 = set.getString(2);
			String surname1 = set.getString(3);
			
			System.out.println(id1+" "+name1+" "+surname1);
		}
	}
		catch(Exception e)
	
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
}
	