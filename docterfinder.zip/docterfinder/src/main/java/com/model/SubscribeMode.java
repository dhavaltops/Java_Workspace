package com.model;

public class SubscribeMode {

	int id;
	String gmail;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGmail1() {
		return gmail;
	}
	public void setGmail(String gmail) {
		this.gmail = gmail;
	}
	public String getGmail() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
