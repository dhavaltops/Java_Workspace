package com.model;

public class AppointmentModel {
	int id;
	String mydepartment,docter,date,time,name,phone,message
	;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getMydepartment() {
		return mydepartment;
	}
	public void setMydepartment(String mydepartment) {
		this.mydepartment = mydepartment;
	}
	public String getDocter() {
		return docter;
	}
	public void setDocter(String docter) {
		this.docter= docter;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
