package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.AppointmentModel;
import com.model.ContactModel;
import com.model.SignupModel;
import com.model.SubscribeMode;


public class WebDao 
{
	public static Connection getconnect()
	{
		Connection con=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/docter","root","");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
	public static int adddata(SignupModel m)
	{
		int status =0;
		Connection con = WebDao.getconnect();
		
		try
		{
			PreparedStatement ps = con.prepareStatement("insert into signup(name,email,password)value(?,?,?)");
			ps.setString(1,m.getName());
			ps.setString(2,m.getEmail());
			ps.setString(3,m.getPassword());
			
			status = ps.executeUpdate();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	public static SignupModel CheckLogin(SignupModel model)
	{
		boolean flag  = false;
		SignupModel obj = null;
		try
		{
			Connection con = WebDao.getconnect();
			PreparedStatement sp = con.prepareStatement("select * from signup where email=? and password=?");
			sp.setString(1,model.getEmail());
			sp.setString(2,model.getPassword());
			
			ResultSet set=sp.executeQuery();
			
			while(set.next())
			{
				obj = new SignupModel();
				obj.setName(set.getString("name"));
				obj.setEmail(set.getString("email"));
				obj.setPassword(set.getString("password"));				
			}
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
		return obj;
	}
	public static int ContactForm(ContactModel m) {
		int status = 0;
		
		Connection con = WebDao.getconnect();
		try {
			PreparedStatement ps = con.prepareStatement("insert into contactus(name,email,query,number,message) values (?,?,?,?,?)");
			ps.setString(1, m.getName());
			ps.setString(2, m.getEmail());
			ps.setString(3, m.getQuery());
			ps.setString(4, m.getNumber());
			ps.setString(5, m.getMessage());
			
			status = ps.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return status;
	}
	public static int AppoinmentForm(AppointmentModel m) {
		int status = 0;
		Connection con = WebDao.getconnect();
		try {
			PreparedStatement ps = con.prepareStatement("insert into appointment(mydepartment,docter,date,time,name,phone,message) values (?,?,?,?,?,?,?)");
			ps.setString(1, m.getMydepartment());
			ps.setString(2, m.getDocter());
			ps.setString(3, m.getDate());
			ps.setString(4, m.getTime());
			ps.setString(5, m.getName());
			ps.setString(6, m.getPhone());
			ps.setString(7, m.getMessage());
			
			status =ps.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		return status;
	}
	public static int SubscribeForm(SubscribeMode m) {
		int status = 0;
		Connection con = WebDao.getconnect();
		try {
			PreparedStatement ps = con.prepareStatement("insert into subscribe(gmail) values (?)");
			ps.setString(1, m.getGmail1());
			
		
			status = ps.executeUpdate();	
			}
		 catch (SQLException e) {
				e.printStackTrace();
			}
		return status;
	}
}



	
		
	
		
			
		
	
		
		
	